# webapp



# Introuduction:
This web application runs on Nodejs server and MySQL database.
    1. GET: /v1/assignments
    2. POST: /v1/assignments
    3. GET: /v1/assignments/{id}
    4. DELETE: /v1/assignments/{id}
    5. PUT: /v1/assignments/{id}
    6. PATCH: /v1/assignments/{id}
    7. GET: /healthz

to start the app 
npm start

to run test
nom test

to run on debian


# debian

To connect to the server 

$ ssh -i .ssh/digitalocean root@68.183.62.253

# apt install node npm
# apt install nodejs npm
# rm -rf node_modules
#npm i
#npm start


maria db
~/testapp# mysql -u root -p

to copy file 
scp -i ~/.ssh/digitalocean /Users/harshinivc/Documents/webapp.zip root@68.183.62.253:/root/testapp

unzip
~/testapp# unzip webapp.zip 

Assignment 5
Added Packer file to build AMI on AWS
app.sh for the shell commands 






