
const bcrypt = require('bcrypt');


module.exports = {bcrypt };